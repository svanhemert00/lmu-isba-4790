This is a Blog App for Gamers! It is an app where you can write blog posts about your favorite video games, characters, and much more! The app also allows you to delete, edit/update the articles and even add a url to your blog posts. This is useful for a gamer blog, so feel free to share all of your game-related links, whether that is a discount on your favorite game or an in depth analysis of the entire lore of Skyrim, the possibilities are endless! 

The security policy only allows you to view the blog posts until you sign in. Once you do, you will have full access to all features of the app!

The image used in the app icon was taken from Google images. 
